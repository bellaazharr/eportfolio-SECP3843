import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily Activities Recorder',
      theme: ThemeData(
        fontFamily: 'SF Pro Display',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1A1A24)),
        useMaterial3: true,
      ),
      home: const ActivityHomePage(),
    );
  }
}

// ── Data model ──────────────────────────────────────────────────
class Activity {
  final String name;
  final String timeOrCategory;
  final String emoji;
  bool isDone;

  Activity({
    required this.name,
    required this.timeOrCategory,
    required this.emoji,
    this.isDone = false,
  });
}

// ── Emoji helper ─────────────────────────────────────────────────
String _pickEmoji(String category) {
  final c = category.toLowerCase();
  if (c.contains('exercise') ||
      c.contains('jog') ||
      c.contains('run') ||
      c.contains('gym'))
    return '🏃';
  if (c.contains('study') ||
      c.contains('class') ||
      c.contains('learn') ||
      c.contains('flutter'))
    return '📖';
  if (c.contains('eat') ||
      c.contains('breakfast') ||
      c.contains('lunch') ||
      c.contains('dinner') ||
      c.contains('meal') ||
      c.contains('food'))
    return '🥗';
  if (c.contains('sleep') || c.contains('rest') || c.contains('nap'))
    return '😴';
  if (c.contains('work') || c.contains('task') || c.contains('meeting'))
    return '💼';
  if (c.contains('wake') || c.contains('morning')) return '☀️';
  return '✦';
}

// ── Main Page ────────────────────────────────────────────────────
class ActivityHomePage extends StatefulWidget {
  const ActivityHomePage({super.key});

  @override
  State<ActivityHomePage> createState() => _ActivityHomePageState();
}

class _ActivityHomePageState extends State<ActivityHomePage> {
  static const _dark = Color(0xFF1A1A24);
  static const _cream = Color(0xFFF7F6F2);
  static const _gold = Color(0xFFE8B86D);
  static const _card = Color(0xFFFFFFFF);

  final List<Activity> _activities = [];
  final _nameCtrl = TextEditingController();
  final _categoryCtrl = TextEditingController();
  final _nameFocus = FocusNode();

  // ── Add ──────────────────────────────────────────────────────
  void _addActivity() {
    final name = _nameCtrl.text.trim();
    final cat = _categoryCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Please enter an activity name.'),
          backgroundColor: _dark,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          margin: const EdgeInsets.all(16),
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }
    setState(() {
      _activities.insert(
        0,
        Activity(
          name: name,
          timeOrCategory: cat.isEmpty ? 'General' : cat,
          emoji: _pickEmoji(name + cat),
        ),
      );
    });
    _nameCtrl.clear();
    _categoryCtrl.clear();
  }

  // ── Delete ───────────────────────────────────────────────────
  void _deleteActivity(int index) {
    final removed = _activities[index];
    setState(() => _activities.removeAt(index));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('"${removed.name}" removed'),
        backgroundColor: _dark,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'Undo',
          textColor: _gold,
          onPressed: () => setState(() => _activities.insert(index, removed)),
        ),
      ),
    );
  }

  // ── Toggle done ──────────────────────────────────────────────
  void _toggleDone(int index) {
    setState(() => _activities[index].isDone = !_activities[index].isDone);
  }

  // ── Counts ───────────────────────────────────────────────────
  int get _doneCount => _activities.where((a) => a.isDone).length;

  // ── BUILD ────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _cream,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildStatsRow(),
            _buildSectionLabel(),
            Expanded(child: _buildList()),
            _buildInputBar(),
          ],
        ),
      ),
    );
  }

  // ── HEADER ───────────────────────────────────────────────────
  Widget _buildHeader() {
    final now = DateTime.now();
    final days = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final dayName = days[now.weekday - 1];
    final dateStr = '$dayName, ${now.day} ${months[now.month - 1]}';

    return Container(
      decoration: const BoxDecoration(
        color: _dark,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Good morning',
                style: TextStyle(
                  color: Color(0x70FFFFFF),
                  fontSize: 12,
                  letterSpacing: 0.3,
                ),
              ),
              _Avatar(),
            ],
          ),
          const SizedBox(height: 4),
          RichText(
            text: TextSpan(
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                letterSpacing: -0.5,
              ),
              children: [
                const TextSpan(
                  text: 'My ',
                  style: TextStyle(color: Colors.white),
                ),
                TextSpan(
                  text: 'Activities',
                  style: const TextStyle(color: _gold),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _DatePill(dateStr),
        ],
      ),
    );
  }

  // ── STATS ROW ─────────────────────────────────────────────────
  Widget _buildStatsRow() {
    final total = _activities.length;
    final done = _doneCount;
    final active = total - done;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
      child: Row(
        children: [
          _StatCard(
            'Total',
            '$total',
            'activities',
            total > 0 ? 1.0 : 0,
            const Color(0xFFE8B86D),
          ),
          const SizedBox(width: 10),
          _StatCard(
            'Done',
            '$done',
            'completed',
            total > 0 ? done / total : 0,
            const Color(0xFF7BB86D),
          ),
          const SizedBox(width: 10),
          _StatCard(
            'Active',
            '$active',
            'remaining',
            total > 0 ? active / total : 0,
            const Color(0xFFB86D8E),
          ),
        ],
      ),
    );
  }

  // ── SECTION LABEL ─────────────────────────────────────────────
  Widget _buildSectionLabel() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text(
            'RECORDED',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: Color(0xFF9B9B9B),
              letterSpacing: 1.2,
            ),
          ),
          if (_activities.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: _dark,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${_activities.length}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── LIST ──────────────────────────────────────────────────────
  Widget _buildList() {
    if (_activities.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0x10000000)),
              ),
              child: const Center(
                child: Text(
                  '✦',
                  style: TextStyle(fontSize: 28, color: Color(0xFFE8B86D)),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text(
              'No activities yet',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Color(0xFF888888),
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Add one below to get started',
              style: TextStyle(fontSize: 12, color: Color(0xFFBBBBBB)),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      itemCount: _activities.length,
      itemBuilder: (_, i) => _ActivityCard(
        activity: _activities[i],
        onDelete: () => _deleteActivity(i),
        onToggle: () => _toggleDone(i),
        isFirst: i == 0,
      ),
    );
  }

  // ── INPUT BAR ─────────────────────────────────────────────────
  Widget _buildInputBar() {
    return Container(
      color: _cream,
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 20),
      child: Container(
        decoration: BoxDecoration(
          color: _dark,
          borderRadius: BorderRadius.circular(18),
        ),
        padding: const EdgeInsets.fromLTRB(16, 12, 10, 12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _nameCtrl,
                    focusNode: _nameFocus,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                    cursorColor: _gold,
                    decoration: const InputDecoration(
                      hintText: 'Activity name...',
                      hintStyle: TextStyle(
                        color: Color(0x55FFFFFF),
                        fontSize: 13,
                      ),
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 4),
                      border: InputBorder.none,
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0x20FFFFFF)),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: _gold),
                      ),
                    ),
                    onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                  ),
                  const SizedBox(height: 6),
                  TextField(
                    controller: _categoryCtrl,
                    style: const TextStyle(
                      color: Color(0xAAFFFFFF),
                      fontSize: 11,
                    ),
                    cursorColor: _gold,
                    decoration: const InputDecoration(
                      hintText: 'Time / Category (e.g. 8:00 PM, Exercise)',
                      hintStyle: TextStyle(
                        color: Color(0x35FFFFFF),
                        fontSize: 11,
                      ),
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 4),
                      border: InputBorder.none,
                    ),
                    onSubmitted: (_) => _addActivity(),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: _addActivity,
              child: Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: _gold,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.add, color: _dark, size: 22),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _categoryCtrl.dispose();
    _nameFocus.dispose();
    super.dispose();
  }
}

// ── Activity Card ─────────────────────────────────────────────────
class _ActivityCard extends StatelessWidget {
  final Activity activity;
  final VoidCallback onDelete;
  final VoidCallback onToggle;
  final bool isFirst;

  const _ActivityCard({
    required this.activity,
    required this.onDelete,
    required this.onToggle,
    required this.isFirst,
  });

  @override
  Widget build(BuildContext context) {
    const gold = Color(0xFFE8B86D);
    const dark = Color(0xFF1A1A24);

    return Dismissible(
      key: ValueKey(activity.hashCode),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDelete(),
      background: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFFFEBEB),
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        child: const Text(
          'Delete',
          style: TextStyle(
            color: Color(0xFFB86D4A),
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
      child: GestureDetector(
        onLongPress: onToggle,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border(
              left: BorderSide(
                color: isFirst ? gold : Colors.transparent,
                width: isFirst ? 3 : 0,
              ),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
            child: Row(
              children: [
                // Emoji icon
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F3EE),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                      activity.emoji,
                      style: const TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(width: 12),

                // Name + category
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        activity.name,
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 13,
                          color: dark,
                          decoration: activity.isDone
                              ? TextDecoration.lineThrough
                              : null,
                          decorationColor: dark.withOpacity(0.4),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        activity.timeOrCategory,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Color(0xFFAAAAAA),
                        ),
                      ),
                    ],
                  ),
                ),

                // Status badge
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: activity.isDone
                        ? const Color(0xFFEEF7E8)
                        : const Color(0xFFFEF7EC),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    activity.isDone ? 'Done' : 'Active',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: activity.isDone
                          ? const Color(0xFF3B6D11)
                          : const Color(0xFF854F0B),
                    ),
                  ),
                ),

                const SizedBox(width: 4),

                // Delete button
                GestureDetector(
                  onTap: onDelete,
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Icon(
                      Icons.close_rounded,
                      size: 16,
                      color: Colors.grey.shade300,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Stat Card ─────────────────────────────────────────────────────
class _StatCard extends StatelessWidget {
  final String label;
  final String number;
  final String sub;
  final double progress;
  final Color color;

  const _StatCard(this.label, this.number, this.sub, this.progress, this.color);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0x09000000)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label.toUpperCase(),
              style: const TextStyle(
                fontSize: 9,
                color: Color(0xFF9B9B9B),
                letterSpacing: 0.6,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              number,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Color(0xFF1A1A24),
              ),
            ),
            Text(
              sub,
              style: const TextStyle(fontSize: 9, color: Color(0xFFB0B0B0)),
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(2),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 3,
                backgroundColor: const Color(0xFFF0F0F0),
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Avatar ────────────────────────────────────────────────────────
class _Avatar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFE8C56D), Color(0xFFD4845A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(17),
      ),
      child: const Center(
        child: Text(
          'B',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}

// ── Date Pill ─────────────────────────────────────────────────────
class _DatePill extends StatelessWidget {
  final String date;
  const _DatePill(this.date);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 5, 12, 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: const BoxDecoration(
              color: Color(0xFFE8B86D),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            date,
            style: const TextStyle(color: Color(0x70FFFFFF), fontSize: 11),
          ),
        ],
      ),
    );
  }
}
